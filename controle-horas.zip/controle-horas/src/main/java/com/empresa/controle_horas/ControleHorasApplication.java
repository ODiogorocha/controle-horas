package com.empresa.controle_horas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleHorasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleHorasApplication.class, args);
	}

}
